package practica1;

public abstract class Servivo {
	
	
	public abstract void alimentarse();
	
	
	

}
