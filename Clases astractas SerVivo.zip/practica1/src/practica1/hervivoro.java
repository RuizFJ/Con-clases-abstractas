package practica1;

public class hervivoro extends Servivo {

	@Override
	public void alimentarse() {
		System.out.println("Los hervivoros comen hierva");
		
	}

}
