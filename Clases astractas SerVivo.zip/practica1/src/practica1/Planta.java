package practica1;

import java.util.Scanner;

public class Planta extends Servivo {
	
	Scanner tc = new Scanner(System.in);
	int edad;

	@Override
	public void alimentarse() {
	System.out.println("Escriba la edad de la planta");
		edad=tc.nextInt();
		System.out.println("Las plantas hacen la fotosintesis y su edad es "+edad);
	}

}
