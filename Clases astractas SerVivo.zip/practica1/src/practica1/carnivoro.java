package practica1;

public class carnivoro extends Servivo {

	@Override
	public void alimentarse() {
		System.out.println("Los carnivoros comen carne");
		
	}

}
