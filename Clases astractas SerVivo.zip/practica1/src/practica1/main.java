package practica1;

import java.util.Scanner;

public class main {

	public static void main(String[] args) {
		
		carnivoro op1 = new carnivoro();
		hervivoro op2 = new hervivoro();
		Planta op3 = new Planta();
		
		Scanner tc = new Scanner(System.in);
		int opc;
		
		
		do {
			System.out.println("Escriba una opcion \n1.Plantas \n2.Carvivoros \n3.Hervivoros \n4.Salir");
			opc=tc.nextInt();
			
		switch (opc) {
		
		case 1:
			op3.alimentarse();
			
			break;
		case 2:
			op1.alimentarse();
			break;
		case 3:
			op2.alimentarse();
			break;
		
		default :
			System.out.println("Dato invalido");
		
		}
		} while (opc!=4);
		

	}

}
